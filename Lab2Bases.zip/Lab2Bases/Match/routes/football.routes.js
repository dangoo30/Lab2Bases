const express = require('express');
const router = express.Router();
const footballDao = require('../dao/football.dao');

router.get('/conteos', footballDao.getConteos);
router.get('/equipo/:nombre', footballDao.getPartidosPorEquipo);

module.exports = router;