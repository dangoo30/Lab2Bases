const db = require('../services/mysql.service');

// Verificación de la carga: conteo de registros por tabla.
const getConteos = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT 'season' AS tabla, COUNT(*) AS registros FROM season
       UNION ALL SELECT 'team', COUNT(*) FROM team
       UNION ALL SELECT 'football_match', COUNT(*) FROM football_match
       UNION ALL SELECT 'team_match_stats', COUNT(*) FROM team_match_stats`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Ejemplo de consulta con JOIN y parámetro: partidos de un equipo.
const getPartidosPorEquipo = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT football_match.match_date, season.label AS temporada,
              team_match_stats.side, team_match_stats.goals
       FROM team_match_stats
       JOIN team ON team.team_id = team_match_stats.team_id
       JOIN football_match ON football_match.match_id = team_match_stats.match_id
       JOIN season ON season.season_id = football_match.season_id
       WHERE team.name = ?
       ORDER BY football_match.match_date`,
      [req.params.nombre]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Equipo no encontrado' });
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { getConteos, getPartidosPorEquipo };