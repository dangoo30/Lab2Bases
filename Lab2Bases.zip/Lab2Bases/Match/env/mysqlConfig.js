const config = {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'football_db'
};

module.exports = config;