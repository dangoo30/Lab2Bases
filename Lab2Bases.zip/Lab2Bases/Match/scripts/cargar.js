// Programa de carga: football_matches.csv -> football_db
// Uso:  npm install csv-parse   y luego   node scripts/cargar.js
// Decisión arquitectónica: script independiente (proceso por lotes de una sola
// ejecución, sin peticiones HTTP). Reutiliza la configuración y el pool del
// proyecto (env/ y services/) pero no usa rutas ni DAO porque no hay cliente.
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const pool = require('../services/mysql.service');

const CSV_PATH = path.join(__dirname, '..', 'data', 'football_matches.csv');

// ---------- Validación (antes de tocar la base de datos) ----------
function entero(valor, campo, linea) {
  const numero = Number(valor);
  if (valor === '' || !Number.isInteger(numero) || numero < 0) {
    throw new Error(`Línea ${linea}: ${campo} debe ser entero >= 0 (llegó "${valor}")`);
  }
  return numero;
}
function posesion(valor, campo, linea) {
  const numero = Number(valor);
  if (valor === '' || !Number.isFinite(numero) || numero < 0 || numero > 100) {
    throw new Error(`Línea ${linea}: ${campo} debe estar entre 0 y 100 (llegó "${valor}")`);
  }
  return numero;
}
function texto(valor, campo, linea) {
  if (!valor || !valor.trim()) throw new Error(`Línea ${linea}: ${campo} vacío`);
  return valor.trim();
}
function fecha(valor, linea) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(valor) || Number.isNaN(Date.parse(valor))) {
    throw new Error(`Línea ${linea}: fecha inválida "${valor}"`);
  }
  return valor;
}

// Solo se leen las columnas justificadas en el pre-laboratorio.
function transformar(fila, linea) {
  return {
    season: texto(fila.season, 'season', linea),
    date: fecha(fila.date, linea),
    home: {
      team: texto(fila.home_team, 'home_team', linea),
      goals: entero(fila.goal_home_ft, 'goal_home_ft', linea),
      possession: posesion(fila.home_possession, 'home_possession', linea),
      shotsOnTarget: entero(fila.home_shots_on_target, 'home_shots_on_target', linea),
      redCards: entero(fila.home_red_cards, 'home_red_cards', linea),
    },
    away: {
      team: texto(fila.away_team, 'away_team', linea),
      goals: entero(fila.goal_away_ft, 'goal_away_ft', linea),
      possession: posesion(fila.away_possession, 'away_possession', linea),
      shotsOnTarget: entero(fila.away_shots_on_target, 'away_shots_on_target', linea),
      redCards: entero(fila.away_red_cards, 'away_red_cards', linea),
    },
  };
}

// ---------- Inserción ----------
async function obtenerId(conexion, cache, tabla, columnaValor, valor) {
  if (cache.has(valor)) return cache.get(valor);
  const [resultado] = await conexion.query(
    `INSERT INTO ${tabla} (${columnaValor}) VALUES (?)`, [valor]
  );
  cache.set(valor, resultado.insertId);
  return resultado.insertId;
}

async function insertarStats(conexion, matchId, teamId, side, datos) {
  await conexion.query(
    `INSERT INTO team_match_stats
       (match_id, team_id, side, goals, possession, shots_on_target, red_cards)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [matchId, teamId, side, datos.goals, datos.possession, datos.shotsOnTarget, datos.redCards]
  );
}

async function main() {
  const filas = parse(fs.readFileSync(CSV_PATH, 'utf8'), {
    columns: true, skip_empty_lines: true, trim: true,
  });
  console.log(`Filas leídas del CSV: ${filas.length}`);

  // 1) Validar todo primero: si hay errores, no se inserta nada.
  const partidos = [];
  const errores = [];
  filas.forEach((fila, indice) => {
    try {
      partidos.push(transformar(fila, indice + 2)); // +2: encabezado + base 1
    } catch (err) {
      errores.push(err.message);
    }
  });
  if (errores.length > 0) {
    console.error(`Se encontraron ${errores.length} filas inválidas. No se insertó nada:`);
    errores.slice(0, 20).forEach((mensaje) => console.error(' - ' + mensaje));
    process.exitCode = 1;
    return;
  }

  // 2) Insertar dentro de una transacción: todo o nada.
  const conexion = await pool.getConnection();
  try {
    const [[{ total }]] = await conexion.query('SELECT COUNT(*) AS total FROM football_match');
    if (total > 0) {
      throw new Error('football_match ya tiene datos. Vacía las tablas antes de volver a cargar.');
    }
    await conexion.beginTransaction();
    const cacheTemporadas = new Map();
    const cacheEquipos = new Map();

    for (const partido of partidos) {
      const seasonId = await obtenerId(conexion, cacheTemporadas, 'season', 'label', partido.season);
      const homeId = await obtenerId(conexion, cacheEquipos, 'team', 'name', partido.home.team);
      const awayId = await obtenerId(conexion, cacheEquipos, 'team', 'name', partido.away.team);
      const [resultado] = await conexion.query(
        'INSERT INTO football_match (season_id, match_date) VALUES (?, ?)',
        [seasonId, partido.date]
      );
      await insertarStats(conexion, resultado.insertId, homeId, 'home', partido.home);
      await insertarStats(conexion, resultado.insertId, awayId, 'away', partido.away);
    }
    await conexion.commit();
  } catch (err) {
    await conexion.rollback();
    console.error('Error durante la carga, se hizo ROLLBACK:', err.message);
    process.exitCode = 1;
    return;
  } finally {
    conexion.release();
  }

  // 3) Verificación: conteo por tabla vs. lo esperado.
  const esperado = { season: 11, team: 37, football_match: partidos.length, team_match_stats: partidos.length * 2 };
  for (const tabla of Object.keys(esperado)) {
    const [[{ total }]] = await pool.query(`SELECT COUNT(*) AS total FROM ${tabla}`);
    const estado = total === esperado[tabla] ? 'OK' : `REVISAR (esperado ${esperado[tabla]})`;
    console.log(`${tabla}: ${total} registros -> ${estado}`);
  }
}

main()
  .catch((err) => { console.error('Fallo inesperado:', err.message); process.exitCode = 1; })
  .finally(() => pool.end());